/*package declaration*/
package com.panchalprogrammingacademy;

/**
 * This program is written to demonstrate one of the way to represent floating-point numbers
 * @author Shubham Panchal
 * */
public class Main{

    // driver function
    // throws IllegalArgumentException if n is not in range [1,64]
    // throws IllegalArgumentException if
    public static void main(String[] args){
        // verify the number of command-line-arguments
        if (args.length == 3){
            // get the total  number of bits
            int n = Integer.parseInt(args[0]);
            // get number of exponent bits
            int e = Integer.parseInt(args[1]);
            // get the name of the file to write data to
            String filename = args[2];
            // create an instance of ListRealNumbers
            ListRealNumbers listRealNumbers = new ListRealNumbers();
            // invoke the procedure for listing numbers
            listRealNumbers.listRealNumbers(n, e, filename);
        } else {
            // invalid number of command line arguments
            String usage = "Usage:\n" +
                    "java -jar ListRealNumbers.jar #totalBits #exponentBits filename\n" +
                    "e.g. java -jar ListRealNumbers.jar 8 3 single_precision_numbers.txt\n" +
                    "e.g. java -jar ListRealNumbers.jar 32 8 single_precision_numbers.txt\n" +
                    "e.g. java -jar ListRealNumbers 64 11 double_precision_numbers.txt\n";
            // give a message to user
            System.out.println(usage);
        }
    }
}