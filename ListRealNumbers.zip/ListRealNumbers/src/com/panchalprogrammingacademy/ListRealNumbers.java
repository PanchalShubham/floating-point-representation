/*package declaration*/
package com.panchalprogrammingacademy;


/*necessary imports*/
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Lists all real numbers along with Infinity, NaN and denormalized numbers
 * for given total number of bits and number of exponent bits
 * */
public final class ListRealNumbers {
    // used for construction of result
    private StringBuilder stringBuilder;
    // used to store the filename
    private String filename;
    // used to store the total number of bits
    private int n;
    // stores the number of exponent bits
    private int e;
    // used for computation
    private int bias;

    // returns the integer representation of binary within given range
    private int binaryToInt(int[] binary, int low, int high){
        // stores the result of computation
        int result = 0;
        // stores the multiplication factor
        int factor = 1;
        // iterate through values
        for (int i = high; i >= low; --i){
            // add binary[i]*2^i to result
            result += binary[i]*factor;
            // multiply factor by 2
            factor *= 2;
        }
        // return the computed result
        return result;
    }

    // returns the double w.r.t negative exponents
    private double binaryToNegativeDouble(int[] binary, int low, int high){
        // start with value of 1.0
        double val = 1.0;
        // start with 2^-1
        double multiplication_factor = 0.5;
        // iterate through range
        for (int i = low; i <= high; ++i){
            // add negative power of 2
            val += binary[i]*multiplication_factor;
            // divide the multiplication factor by 2
            multiplication_factor /= 2;
        }
        // return the computed value
        return val;
    }

    // returns true if all bits in given range are set to 1
    private boolean areAllBitsSet(int[] binary, int low, int high){
        // iterate through given range
        for (int i = low; i <= high; ++i) if (binary[i] != 1) return false;
        // all bits in given range are set
        return true;
    }

    // returns true if all bits in given range are set to 0
    private boolean areAllBitsNotSet(int[] binary, int low, int high){
        // iterate through given range
        for (int i = low; i <= high; ++i) if (binary[i] != 0) return false;
        // all bits in given range are not set
        return true;
    }

    // compute the representation of given binary
    private String representBinary(int[] binary){
        // check if all exponent bits are set
        if (areAllBitsSet(binary, 1, e)){
            // all exponent bits are zero check if all mantissa bits are zero
            if (areAllBitsNotSet(binary, e + 1, binary.length - 1)){
                // this represents infinity
                return (binary[0] == 1 ? "Infinity" : "-Infinity");
            } else {
                // this represents NaN
                return "NaN";
            }
        } else if (areAllBitsNotSet(binary, 1, e)){
            // all exponent bits are zero check if all mantissa bits are zero
            if (areAllBitsNotSet(binary, e + 1, binary.length - 1)){
                // this represents a zero
                return "0.0";
            } else {
                // this represents a denormalized number
                // compute the biased-exponent
                int biasedExponent =  1 - bias;
                // compute the representation of mantissa and denormalized value
                double value = Math.pow(-1,binary[0])*binaryToNegativeDouble(binary, e + 1, binary.length - 1)*Math.pow(2, biasedExponent);
                // return the value
                return (value + "d");
            }
        } else {
            // this represents a valid floating-point number
            int exponent = binaryToInt(binary, 1, e);
            // computed biased exponent
            int biasedExponent = exponent - bias;
            // get the double representation of mantissa
            double value = Math.pow(-1,binary[0])*binaryToNegativeDouble(binary, e + 1, binary.length - 1)*Math.pow(2, biasedExponent);
            // return the value
            return String.valueOf(value);
        }
    }

    // returns the string representation of given binary
    private String binaryToString(int[] binary){
        // create a new string builder
        StringBuilder sb = new StringBuilder();
        // string builder to build exponent
        StringBuilder exponent = new StringBuilder();
        for (int i = 1; i <= e; ++i)
            exponent.append(binary[i]);
        // string builder to build mantissa
        StringBuilder mantissa = new StringBuilder();
        for (int i = e + 1; i < binary.length; ++i)
            mantissa.append(binary[i]);
        // create final representation
        sb.append(binary[0]).append("_").append(exponent).append("_").append(mantissa);
        // return the string representation
        return sb.toString();
    }

    // computes the minimum value
    private double minimumAbsoluteValue(){
        // for smallest value we have exponent 00000....00001
        // get the biased exponent
        int biasedExponent = 1 - bias;
        // and mantissa 000..0000
        // return the computed value
        return 1.0*Math.pow(2, biasedExponent);
    }

    // computes the maximum value
    private double maximumAbsoluteValue(){
        // for largest value we have exponent 11..1110
        // computed biased exponent
        int exponent = 0;
        int multiplication_factor = 2;
        for (int i = 1; i < e ; ++i){
            // add multiplication factor to exponent
            exponent += multiplication_factor;
            // multiply the multiplication factor
            multiplication_factor *= 2;
        }
        int biasedExponent = exponent - bias;
        // and mantissa 1111..111 ~ 2.0
        // return the computed value
        return 2.0*Math.pow(2, biasedExponent);
    }

    // process all binaries one by one
    private void processBinary(){
        // instead of computing all possible binaries using recursion
        // we use another time-consuming approach to get rid of stack-overflow
        // for 2^32 recursive calls for example

        // get the maximum possible value 2^(#bits)
        long max = 0, factor = 1;
        // max. integer when all n-bits are set to 1
        for (int i = 0; i < n; ++i){
            // add factor to max
            max += factor;
            // multiply factor by 2
            factor *= 2;
        }
        // now we iterate through each possible value from 1 to 2^n
        // resulting in all binary patterns of length n
        for (long k = 0; k <= max; ++k){
            // get the binary representation of val
            int[] binary = new int[n];
            // take a copy of original value
            long val = k;
            // iterate though array and populate it
            for (int j = n - 1; j >= 0; --j){
                // take remainder w.r.t 2
                binary[j] = (int)(val % 2);
                // divide value by 2
                val /= 2;
            }
            // now we process this binary representation
            stringBuilder.append(String.format("%-65s%-20s\n", binaryToString(binary), representBinary(binary)));
        }
    }


    /**
     * Lists the real numbers along with infinity, NaN and denormalized numbers
     * for given total number of bits N (at least two and at most 64) and number of exponent bits E (at least 1 and at most N)
     * @throws IllegalArgumentException if N is not is range [2,64]
     * @throws IllegalArgumentException if E is not in range [1,N]
     * */
    public void listRealNumbers(int N, int E, String filename) throws IllegalArgumentException{
        // validate user's input
        if (!(2 <= N && N <= 64))
            throw new IllegalArgumentException("IllegalArgumentException: N has to be at least two and at most 64.");
        if (!(1 <= E && E <= N))
            throw new IllegalArgumentException("IllegalArgumentException: E has to be at least 1 and at most N");

        // update the fields
        n = N; e = E;
        // we create a StringBuilder to store the results
        stringBuilder = new StringBuilder();
        // first we compute the bias
        bias = (int)Math.pow(2, e - 1) - 1;
        // write the startup information to string builder
        String disclaimer = "/*****************************************************************************\n" +
                " * This report is generated by ListRealNumbers program                       *\n" +
                " * If you find anything incorrect then please contact author of the program  *\n" +
                " * ListRealNumbers program was written for educational purposes and          *\n" +
                " * the author reserves the right not be responsible for the correctness,     *\n" +
                " * completeness or quality of the information provided. Liability claims     *\n" +
                " * regarding damage caused by the use of the information provided,           *\n" +
                " * included any kind of information which is incomplete or incorrect,        *\n" +
                " * will therefore be rejected.                                               *\n" +
                " * All offers are not-binding and without obligations. Parts of the          *\n" +
                " * program or the complete program including all offers and information      *\n" +
                " * might be extended, changed or partly or completely deleted by the author  *\n" +
                " * without any separate announcement.\n" +
                " *****************************************************************************/ \n\n\n";
        stringBuilder.append(disclaimer);
        stringBuilder.append("#sign bits: 1\n");
        stringBuilder.append("#exponent bits: ").append(e).append("\n");
        stringBuilder.append("#significand bits/mantissa bits: ").append(n - e - 1).append("\n");
        stringBuilder.append("#total bits: ").append(n).append("\n");
        stringBuilder.append("#precision:~ ").append(n - e).append("(approx.)\n");
        stringBuilder.append("#possible-number: ").append((int)Math.pow(2, n)).append("\n");
        stringBuilder.append("#valid-numbers: ").append((int)Math.pow(2, n) - (int)(2*Math.pow(2, n - e - 1) - 2) - 2).append("\n");
        stringBuilder.append("#normal-numbers: ").append((int)Math.pow(2, n) - 2*(2*(int)Math.pow(2, n - e - 1) - 2) - 2).append("\n");
        stringBuilder.append("#de-normal-numbers: ").append(2*(int)Math.pow(2, n - e - 1) - 2).append("\n");
        stringBuilder.append("#NaN: ").append(2*(int)Math.pow(2, n - e - 1) - 2).append("\n");
        stringBuilder.append("#Infinity: 2\n");
        stringBuilder.append("exponent-bias: ").append(bias).append("\n");
        // get the maximum absolute value
        double absMax = maximumAbsoluteValue();
        stringBuilder.append("Max. absolute value:~ ").append(absMax).append("(approx.)\n");
        stringBuilder.append("Min. absolute value:~ ").append(minimumAbsoluteValue()).append("(approx.)\n");
        stringBuilder.append("Approx. range [-").append(absMax).append(", +").append(absMax).append("]\n\n");
        stringBuilder.append("1. Suffix d indicates a denormalized-number e.g. 0.4375d\n");
        stringBuilder.append("2. NaN(Not-a-Number) represents that given binary-representation does not represent a valid number\n");
        stringBuilder.append("3. We have two representation for zero because we are not using two's complement notation\n\n");
        stringBuilder.append(String.format("%-65s%-20s\n", "Binary Number", "Real number"));
        // process the information here
        // process binaries one by one
        processBinary();
        // create a new file with filename
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(new File(filename)))){
            // write content to file
            bw.write(stringBuilder.toString());
            // give a message to user
            System.out.println("Please check \"" +  filename + "\" for list of real numbers generated!");
        } catch (IOException exception){
            // give exception message to user
            System.out.println("IOException: " + exception.getMessage());
            System.out.println("You can contact the owner of file for more information or any help!");
        }
    }

}
